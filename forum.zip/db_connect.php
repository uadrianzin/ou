<?php 

$conn= new mysqli('localhost','adrian','Awa35351@Adrgames','forum_db')or die("Could not connect to mysql".mysqli_error($con));
